## RUN requirements.txt to install all dependencies

## Run the command "pip install -r requirements.txt" to install dependencies, after opening the terminal in the Assignment directory

## for q1 open folder Q1, ensure Train_B_Tree.csv is in the same folder as q1.py.
## run q1.py using command "python q1.py"
## Terminal will contain the conclusions while the regression tree without pruning would be saved in decision_tree.txt and pruned tree would be saved in pruned.txt

## for Q2 open folder Q2, ensure Train_B_Bayesian.csv is in the same folder as q2.py
## run q2.py using command python q2.py
## Terminal will contain the outliers found and results of the accuracy of the model.

## Assignment-1.pdf would contain the report and indepth description about both the questions
