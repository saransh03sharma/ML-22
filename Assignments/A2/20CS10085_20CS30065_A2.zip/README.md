## RUN requirements.txt to install all dependencies

## Run the command "pip install -r requirements.txt" to install dependencies, after opening the terminal 

## for q1 ensure iris.data is in the same folder as q1.py.
## run q1.py using command "python q1.py"
## Terminal will contain the conclusions and other results.
## To redirect output to text use command "python q1.py > q1_output.txt"
## PCA.csv contains the dataset after PCA is applied.

## for q2, ensure iris.data is in the same folder as q2.py
## run q2.py using command python q2.py
## Terminal will contain the conclusions and results of the accuracy of different models.
## To redirect output to text use command "python q2.py > q2_output.txt"

## 20CS10085_20CS30065_report.pdf would contain the report and indepth description about both the questions
